CREATE DATABASE attandance_db;
USE attandance_db;

-- Teachers Table (with cnic, mobile, photo)
CREATE TABLE teachers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    cnic VARCHAR(20),
    mobile VARCHAR(20),
    photo VARCHAR(255)
);

-- Students Table
CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    roll_no INT NOT NULL UNIQUE,
    email VARCHAR(100),
    cnic VARCHAR(20),
    mobile VARCHAR(20),
    section VARCHAR(50),
    photo VARCHAR(255)
);

-- Attendance Table

CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    status VARCHAR(20) DEFAULT 'Absent',
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);



-- Attendance Warnings Table
CREATE TABLE attendance_warnings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    message TEXT NOT NULL,
    date DATE NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- View for attendance percentage (last 30 days)
CREATE VIEW attendance_percentage AS
SELECT 
    s.id AS student_id,
    s.name,
    s.roll_no,
    COUNT(a.id) AS total_attendance,
    (COUNT(a.id) / 30) * 100 AS attendance_percentage
FROM students s
LEFT JOIN attendance a ON s.id = a.student_id
AND a.date >= CURDATE() - INTERVAL 30 DAY
GROUP BY s.id, s.name, s.roll_no;

-- Stored Procedure: Check if teacher email exists
DELIMITER //
CREATE PROCEDURE check_teacher_email(IN p_email VARCHAR(100))
BEGIN
    SELECT COUNT(*) AS email_count FROM teachers WHERE email = p_email;
END //
DELIMITER ;



-- Register Teacher
DELIMITER //
CREATE PROCEDURE register_teacher (
    IN p_name VARCHAR(100),
    IN p_email VARCHAR(100),
    IN p_password VARCHAR(255),
    IN p_cnic VARCHAR(20),
    IN p_mobile VARCHAR(20),
    IN p_photo VARCHAR(255)
)
BEGIN
    INSERT INTO teachers (name, email, password, cnic, mobile, photo)
    VALUES (p_name, p_email, p_password, p_cnic, p_mobile, p_photo);
END //
DELIMITER ;

-- Get teacher by email
DELIMITER //
CREATE PROCEDURE get_teacher_by_email(IN p_email VARCHAR(100))
BEGIN
    SELECT * FROM teachers WHERE email = p_email;
END //
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE update_teacher_password (IN p_teacher_id INT, IN p_password VARCHAR(255))
BEGIN
    UPDATE teachers SET password = p_password WHERE id = p_teacher_id;
END$$
DELIMITER ;



-- Check if student exists by roll number
DELIMITER //
CREATE PROCEDURE check_student_roll_no(IN p_roll_no VARCHAR(50))
BEGIN
    SELECT COUNT(*) AS student_count FROM students WHERE roll_no = p_roll_no;
END //
DELIMITER ;

-- Register a new student
DELIMITER //
CREATE PROCEDURE register_student (
    IN p_name VARCHAR(100),
    IN p_roll_no VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_cnic VARCHAR(20),
    IN p_mobile VARCHAR(20),
    IN p_section VARCHAR(50),
    IN p_photo VARCHAR(255)
)
BEGIN
    INSERT INTO students (name, roll_no, email, cnic, mobile, section, photo)
    VALUES (p_name, p_roll_no, p_email, p_cnic, p_mobile, p_section, p_photo);
    
    SELECT LAST_INSERT_ID(); -- so app can fetch student id
END //
DELIMITER ;

-- Get all students
DELIMITER //
CREATE PROCEDURE get_all_students()
BEGIN
    SELECT id, name, roll_no, section, email, mobile FROM students;
END //
DELIMITER ;


DELIMITER //
CREATE PROCEDURE get_student_by_id (
    IN p_student_id INT
)
BEGIN
    SELECT id, name, roll_no, section, email, mobile , photo
    FROM students 
    WHERE id = p_student_id;
END //
DELIMITER ;


DELIMITER $$

CREATE PROCEDURE search_student_by_roll(IN roll_no_input VARCHAR(50))
BEGIN
    SELECT * FROM students
    WHERE roll_no = roll_no_input;
END$$

DELIMITER ;


DELIMITER //
CREATE PROCEDURE update_student_info (
    IN p_student_id INT, 
    IN p_name VARCHAR(255), 
    IN p_roll_no VARCHAR(50),
    IN p_section VARCHAR(50),
    IN p_email VARCHAR(255), 
    IN p_mobile VARCHAR(50) 
)
BEGIN
    UPDATE students
    SET name = p_name, roll_no = p_roll_no, section = p_section, email = p_email, mobile = p_mobile 
    WHERE id = p_student_id;
END //
DELIMITER ;



DELIMITER //
CREATE PROCEDURE delete_student (
    IN p_student_id INT
)
BEGIN
    DELETE FROM students WHERE id = p_student_id;
END //
DELIMITER ;


-- Mark student attendance
DELIMITER //

CREATE PROCEDURE mark_student_attendance (
    IN p_student_id INT,
    IN p_roll_no VARCHAR(50),
    IN p_date DATE,
    IN p_time TIME,
    IN p_status VARCHAR(20),
    OUT p_message VARCHAR(100)
)
BEGIN
    -- Check if attendance already exists for today
    IF NOT EXISTS (
        SELECT 1 FROM attendance
        WHERE student_id = p_student_id AND date = p_date
    ) THEN
        -- Insert attendance record
        INSERT INTO attendance (student_id, date, time, status)
        VALUES (p_student_id, p_date, p_time, p_status);

        SET p_message = 'Attendance marked successfully.';
    ELSE
        SET p_message = 'Attendance already marked today.';
    END IF;
END //

DELIMITER ;


-- Get attendance records
DELIMITER //

CREATE PROCEDURE get_attendance_records()
BEGIN
    SELECT 
        a.id AS attendance_id,
        s.id AS student_id,
        s.name AS student_name, 
        s.roll_no, 
        a.date, 
        a.time, 
        a.status
    FROM 
        attendance a
    JOIN 
        students s 
        ON a.student_id = s.id
    ORDER BY 
        a.date DESC, a.time DESC;
END //

DELIMITER ;




DELIMITER //
CREATE PROCEDURE generate_attendance_warnings()
BEGIN
    DECLARE days INT DEFAULT 30;

    INSERT INTO attendance_warnings (student_id, message, date)
    SELECT
        s.id,
        CONCAT('Attendance percentage is ', 
               ROUND(IFNULL(a.total_attendance / d.total_days * 100, 0), 2),
               '%. Minimum required: 75%'),
        CURDATE()
    FROM students s
    LEFT JOIN (
        SELECT student_id, COUNT(*) AS total_attendance
        FROM attendance
        WHERE date >= CURDATE() - INTERVAL days DAY
        GROUP BY student_id
    ) a ON s.id = a.student_id
    CROSS JOIN (
        SELECT COUNT(DISTINCT date) AS total_days
        FROM attendance
        WHERE date >= CURDATE() - INTERVAL days DAY
    ) d
    WHERE IFNULL(a.total_attendance / d.total_days * 100, 0) < 75;
END //
DELIMITER ;

-- Get attendance warnings
DELIMITER //
CREATE PROCEDURE get_attendance_warnings()
BEGIN
    SELECT w.id, s.name, s.roll_no, w.message, w.date
    FROM attendance_warnings w
    JOIN students s ON w.student_id = s.id
    ORDER BY w.date DESC;
END //
DELIMITER ;

-- Export attendance to CSV
DELIMITER //
CREATE PROCEDURE get_attendance_csv()
BEGIN
    SELECT s.name, s.roll_no, a.date, a.time
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    ORDER BY a.date DESC, a.time DESC;
END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE get_teacher_by_id (
    IN p_teacher_id INT
)
BEGIN
    SELECT id, name, email, cnic, mobile, photo
    FROM teachers
    WHERE id = p_teacher_id;
END //

DELIMITER ;

DELIMITER $$

CREATE PROCEDURE update_teacher_profile(
    IN p_id INT,
    IN p_name VARCHAR(255),
    IN p_email VARCHAR(255),
    IN p_cnic VARCHAR(20),
    IN p_mobile VARCHAR(20),
    IN p_photo VARCHAR(255)
)
BEGIN
    UPDATE teachers
    SET 
        name = p_name,
        email = p_email,
        cnic = p_cnic,
        mobile = p_mobile,
        photo = IFNULL(p_photo, photo)
    WHERE id = p_id;
END$$

DELIMITER ;


DELIMITER //
CREATE PROCEDURE delete_teacher_by_id(IN p_id INT)
BEGIN
  DELETE FROM teachers WHERE id = p_id;
END //
DELIMITER ;

DELIMITER $$


ALTER TABLE attendance ADD COLUMN status VARCHAR(10) DEFAULT 'present';

select * from teachers;