import os
import cv2
import mysql.connector
import numpy as np
import base64
from io import BytesIO
from PIL import Image
from datetime import date, datetime

# Base directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Paths
TRAINER_PATH = os.path.join(BASE_DIR, 'trainer.yml')
CASCADE_PATH = os.path.join(BASE_DIR, 'haarcascade_frontalface_default.xml')
IMAGES_DIR = os.path.join(BASE_DIR, 'static', 'uploads', 'students')

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='AhMaR120',
        database='attandance_db'
    )

def mark_attendance_db(student_id, roll_no, status="Present"):
    current_date = date.today()
    current_time = datetime.now().time()

    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            
            out_message = cursor.callproc('mark_student_attendance', 
                                          (student_id, roll_no, current_date, current_time, status, ''))
            
            
            message = out_message[-1]
            conn.commit()
            return message

# Training model for new faces and sving it for attandance
def train_and_save_model():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    face_cascade = cv2.CascadeClassifier(CASCADE_PATH)

    face_samples = []
    ids = []

    for image_file in os.listdir(IMAGES_DIR):
        if image_file.lower().endswith(('.png', '.jpg', '.jpeg')):
            try:
                id_ = int(os.path.splitext(image_file)[0])
            except ValueError:
                print(f"Skipping non-numeric filename: {image_file}")
                continue

            img_path = os.path.join(IMAGES_DIR, image_file)
            img = cv2.imread(img_path)
            if img is None:
                continue

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            for (x, y, w, h) in faces:
                face_samples.append(gray[y:y+h, x:x+w])
                ids.append(id_)

    if face_samples:
        recognizer.train(face_samples, np.array(ids))
        recognizer.save(TRAINER_PATH)
        print(f"Model trained on {len(face_samples)} face samples.")
    else:
        print("No faces found for training.")

def recognize_and_mark_attendance(image_data):
    if "," in image_data:
        image_data = image_data.split(",")[1]

    img_data = base64.b64decode(image_data)
    img = Image.open(BytesIO(img_data)).convert('RGB')
    img = np.array(img)
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    face_cascade = cv2.CascadeClassifier(CASCADE_PATH)
    if face_cascade.empty():
        raise Exception(f"Failed to load Haar cascade from {CASCADE_PATH}")

    if not os.path.exists(TRAINER_PATH):
        raise Exception("Trainer file not found. Please train the model first.")

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(TRAINER_PATH)

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    results = []

    with get_db_connection() as conn:
        with conn.cursor(dictionary=True) as cursor:
            cursor.callproc('get_all_students')
            for result in cursor.stored_results():
                students = result.fetchall()

    id_student_map = {int(s['roll_no']): (s['id'], s['name']) for s in students}

    for (x, y, w, h) in faces:
        id_, conf = recognizer.predict(gray[y:y+h, x:x+w])
        if conf < 80:
            student_info = id_student_map.get(id_, None)
            if student_info:
                student_id, full_name = student_info
                message = mark_attendance_db(student_id, id_, "Present")
                results.append(f"Student ID: {student_id},  Roll No: {id_},   Name: {full_name},  {message}")
            else:
                results.append("Unknown Face")
        else:
            results.append("Unknown Face")

    return results
