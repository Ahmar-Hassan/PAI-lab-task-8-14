from flask import Flask, render_template, request, redirect, flash , session, send_file, jsonify
import csv
import mysql.connector
from io import StringIO, BytesIO
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os 
from model import recognize_and_mark_attendance , train_and_save_model


app = Flask(__name__)
app.secret_key = 'Smart Attandandance System #$*% 56561818'

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='AhMaR120',
        database='attandance_db'
    )

@app.route('/')
def home():
    return render_template('login.html')


#Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        try:
            with get_db_connection() as conn:
                with conn.cursor(dictionary=True) as cursor:
                    cursor.callproc('get_teacher_by_email', (email,))
                    for result in cursor.stored_results():
                        teacher = result.fetchone()
            if teacher and check_password_hash(teacher['password'], password):
                session['teacher_id'] = teacher['id']
                return redirect('/dashboard')
            else:
                return 'Invalid email or password.'
        except Exception as e:
            return f'Error during login: {str(e)}'
    return render_template('login.html')


# Register Route
@app.route('/register_teacher', methods=['GET', 'POST'])
def register_teacher():
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        password = request.form['password']
        cnic = request.form['cnic']
        mobile = request.form['mobile_no']
        photo = request.files.get('photo')
        photo_filename = None

        if photo and photo.filename != '':
            upload_path = 'static/uploads/teachers'
            if not os.path.exists(upload_path):
                os.makedirs(upload_path)
            photo_filename = secure_filename(photo.filename)
            photo.save(os.path.join(upload_path, photo_filename))

        hashed_password = generate_password_hash(password)

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.callproc('check_teacher_email', (email,))
                    email_exists = False
                    for result in cursor.stored_results():
                        row = result.fetchone()
                        if row and row[0] > 0:
                            email_exists = True
                            break

                    if email_exists:
                        return 'Email already registered.'

                    cursor.callproc('register_teacher', (full_name, email, hashed_password, cnic, mobile, photo_filename))
                    conn.commit()

            return redirect('/')
        except Exception as e:
            return f'Error during registration: {str(e)}'

    return render_template('register_teacher.html')


#Password Reset 

@app.route('/password_reset', methods=['GET', 'POST'])
def password_reset():
    if request.method == 'POST':
        if 'email' in request.form:
            email = request.form['email']

            with get_db_connection() as conn:
                with conn.cursor(dictionary=True) as cursor:
                    cursor.callproc('get_teacher_by_email', (email,))
                    for result in cursor.stored_results():
                        teacher = result.fetchone()

            if teacher:
                session['reset_teacher_id'] = teacher['id']  
                return render_template('password_reset.html', step='reset')
            else:
                flash('Email not found in records.', 'danger')
                return render_template('password_reset.html', step='email')

        elif 'new_password' in request.form:
           
            new_password = request.form['new_password']
            hashed_password = generate_password_hash(new_password)
            teacher_id = session.get('reset_teacher_id')

            if not teacher_id:
                flash('Session expired. Please try again.', 'danger')
                return redirect('/password_reset')

            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.callproc('update_teacher_password', (teacher_id, hashed_password))
                    conn.commit()

            session.pop('reset_teacher_id', None) 
            flash('Password updated successfully. You may now log in.', 'success')
            return redirect('/login')

    
    return render_template('password_reset.html', step='email')


# Dashboard Route

@app.route('/dashboard')
def dashboard():
    if 'teacher_id' not in session:
        return redirect('/')
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.callproc('get_teacher_by_id', (session['teacher_id'],))
                teacher = None
                for result in cursor.stored_results():
                    teacher = result.fetchone()
                if teacher:
                    return render_template('dashboard.html', full_name=teacher[1], photo=teacher[5])
                else:
                    return 'Teacher not found'
    except Exception as e:
        return f'Error loading dashboard: {str(e)}'


# Student Register Route
@app.route('/register_student', methods=['GET', 'POST'])
def register_student():
    if 'teacher_id' not in session:
        return redirect('/')

    if request.method == 'POST':
        name = request.form['name']
        roll_no = request.form['roll_no']
        email = request.form['email']
        cnic = request.form['cnic']
        mobile = request.form['mobile_no']
        section = request.form['section']
        photo = request.files['photo']

        if photo.filename == '':
            return 'No image selected.'

        
        photo_filename = f"{roll_no}.jpg"
        photo_path = os.path.join('static/uploads/students', photo_filename)
        photo.save(photo_path)

        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                
                cursor.callproc('check_student_roll_no', (roll_no,))
                for result in cursor.stored_results():
                    student_count = result.fetchone()[0]
                    if student_count > 0:
                        return 'Roll number already registered.'

               
                cursor.callproc('register_student', (
                    name, roll_no, email, cnic, mobile, section, photo_filename
                ))
                for result in cursor.stored_results():
                    student_id_row = result.fetchone()
                    student_id = student_id_row[0] if student_id_row else None

            conn.commit()

        if not student_id:
            return 'Failed to retrieve student ID.'

        
        train_and_save_model()

        return redirect('/dashboard')

    return render_template('register_student.html')


# Mark Attendance Route

@app.route('/mark_attendance', methods=['GET', 'POST'])
def mark_attendance_page():
    if request.method == 'GET':
        return render_template('mark_attendance.html')

    if request.method == 'POST':
        try:
           
            data = request.get_json()
            image_data = data.get('image')

            if not image_data:
                return jsonify({'error': 'No image data received'}), 400

           
            results = recognize_and_mark_attendance(image_data)  
            return jsonify({'results': results})

        except Exception as e:
            return jsonify({'error': str(e)}), 500
        

# View Attendance Route
@app.route('/view_attendance')
def view_attendance():
    if 'teacher_id' not in session:
        return redirect('/')

    with get_db_connection() as conn:
        with conn.cursor(dictionary=True) as cursor:
            cursor.callproc('get_attendance_records')
            for result in cursor.stored_results():
                records = result.fetchall()

    return render_template('view_attendance.html', records=records)


#Attendance Warning Route

@app.route('/attendance_warnings')
def attendance_warnings():
    if 'teacher_id' not in session:
        return redirect('/')
    try:
        with get_db_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.callproc('generate_attendance_warnings')
                conn.commit()
                cursor.callproc('get_attendance_warnings')
                for result in cursor.stored_results():
                    warnings = result.fetchall()
        return render_template('attendance_warnings.html', warnings=warnings)
    except Exception as e:
        return f"Error: {str(e)}"

#Download Attendance Route
@app.route('/download_attendance')
def download_attendance():
    if 'teacher_id' not in session:
        return redirect('/')
    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.callproc('get_attendance_csv')
            for result in cursor.stored_results():
                rows = result.fetchall()
    string_io = StringIO()
    writer = csv.writer(string_io)
    writer.writerow(['Name', 'Roll No', 'Date', 'Time'])
    for row in rows:
        writer.writerow(row)
    byte_io = BytesIO()
    byte_io.write(string_io.getvalue().encode('utf-8'))
    byte_io.seek(0)
    return send_file(byte_io, mimetype='text/csv', as_attachment=True, download_name='attendance_records.csv')


#View Student Route
@app.route('/view_students')
def view_students():
    roll_no = request.args.get('roll_no')

    with get_db_connection() as conn:
        with conn.cursor(dictionary=True) as cursor:
            if roll_no:
                cursor.callproc('search_student_by_roll', (roll_no,))
                for result in cursor.stored_results():
                    students = result.fetchall()
            else:
                cursor.callproc('get_all_students')
                for result in cursor.stored_results():
                    students = result.fetchall()

    return render_template('view_students.html', students=students, roll_no=roll_no)



#Edit Student Route

@app.route('/edit_student/<int:student_id>', methods=['GET', 'POST'])
def edit_student(student_id):
    
    with get_db_connection() as conn:
        with conn.cursor(dictionary=True) as cursor:
            if request.method == 'POST':
                name = request.form['name']
                roll_no = request.form['roll_no']
                section = request.form['section']
                email = request.form['email']
                mobile = request.form['mobile']

                
                cursor.callproc('update_student_info', (student_id, name, roll_no, section, email, mobile))
                conn.commit()
                return redirect('/view_students')

          
            cursor.callproc('get_student_by_id', (student_id,))
            for result in cursor.stored_results():
                student = result.fetchone()

    return render_template('edit_student.html', student=student)



@app.route('/delete_student/<int:student_id>', methods=['GET'])
def delete_student(student_id):
    print(f"Deleting student with ID: {student_id}")
    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.callproc('delete_student', (student_id,))
            conn.commit()
    return redirect('/view_students')




# Profile view
@app.route('/profile')
def profile():
    if 'teacher_id' not in session:
        return redirect('/')

    conn = get_db_connection()
    teacher = None
    try:
        with conn.cursor(dictionary=True) as cursor:
            cursor.callproc('get_teacher_by_id', (session['teacher_id'],))
            for result in cursor.stored_results():
                teacher = result.fetchone()
    finally:
        conn.close()

    return render_template('profile.html', teacher=teacher)

#Edit Profile Route
@app.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    if 'teacher_id' not in session:
        return redirect('/')

    conn = get_db_connection()
    with conn.cursor(dictionary=True) as cursor:
        cursor.callproc('get_teacher_by_id', (session['teacher_id'],))
        for result in cursor.stored_results():
            teacher = result.fetchone()

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        cnic = request.form['cnic']
        mobile = request.form['mobile']

       
        photo_file = request.files.get('photo')
        photo_filename = None
        if photo_file and photo_file.filename != '':
            photo_filename = f"{session['teacher_id']}_{photo_file.filename}"
            photo_file.save(os.path.join('static/uploads/teachers/', photo_filename))

        
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.callproc('update_teacher_profile', (
                session['teacher_id'], name, email, cnic, mobile, photo_filename
            ))
            conn.commit()
        conn.close()

        return redirect('/profile')

    conn.close()
    return render_template('edit_profile.html', teacher=teacher)

# Delete Profile Route
@app.route('/delete_profile', methods=['POST'])
def delete_profile():
    if 'teacher_id' not in session:
        return redirect('/')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.callproc('delete_teacher_by_id', (session['teacher_id'],))
    conn.commit()
    cursor.close()
    conn.close()

    session.clear()
    return redirect('/')


#Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
