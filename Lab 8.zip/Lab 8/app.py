from flask import Flask, render_template, request, redirect
import pandas as pd

app = Flask(__name__)
CSV_FILE = 'vehicles.csv'

def load_data():
    return pd.read_csv(CSV_FILE)

def save_data(df):
    df.to_csv(CSV_FILE, index=False)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    reg_number = request.form['reg_number'].strip().lower()
    df = load_data()
    record = df[df['reg_number'].str.lower() == reg_number]
    if not record.empty:
        return render_template('result.html', vehicle=record.iloc[0])
    else:
        return render_template('result.html', vehicle=None)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        data = {
            'reg_number': request.form['reg_number'],
            'owner': request.form['owner'],
            'brand': request.form['brand'],
            'model': request.form['model'],
            'year': request.form['year'],
            'fuel_type': request.form['fuel_type'],
            'color': request.form['color'],
        }
        df = load_data()
        df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
        save_data(df)
        return redirect('/')
    return render_template('add_vehicle.html')

if __name__ == '__main__':
    app.run(debug=True)
