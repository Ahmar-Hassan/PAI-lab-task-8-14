from flask import Flask, render_template, request
import pandas as pd
from difflib import get_close_matches

app = Flask(__name__)


df = pd.read_csv('medical data.csv')
patterns = df['pattern'].tolist()
responses = df['response'].tolist()


def get_response(user_input):
    user_input = user_input.lower()
    matches = get_close_matches(user_input, patterns, n=1, cutoff=0.4)
    if matches:
        index = patterns.index(matches[0])
        return responses[index]
    return "I'm not sure about that. Please consult a healthcare professional."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def chatbot_reply():
    user_input = request.form['user_input']
    reply = get_response(user_input)
    return render_template('response.html', user_input=user_input, reply=reply)

if __name__ == '__main__':
    app.run(debug=True)
