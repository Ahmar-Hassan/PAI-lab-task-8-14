import pandas as pd
from difflib import get_close_matches


df = pd.read_csv('medical data.csv')  


patterns = df['pattern'].tolist()
responses = df['response'].tolist()


def get_response(user_input):
    user_input = user_input.lower()
    matches = get_close_matches(user_input, patterns, n=1, cutoff=0.4)
    if matches:
        index = patterns.index(matches[0])
        return responses[index]
    else:
        return "I'm not sure how to help with that. Please consult a doctor if it's serious."


def chatbot():
    print("🤖 Medical Chatbot (Type 'exit' to quit)\n")
    while True:
        user_input = input("You: ")
        if user_input.lower() == 'exit':
            print("Bot: Take care! 👋")
            break
        response = get_response(user_input)
        print(f"Bot: {response}\n")

if __name__ == '__main__':
    chatbot()
